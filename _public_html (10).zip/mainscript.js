

mySwiper1 = new Swiper('.h__partners-swiper1', {
    grabCursor: false,
    loop: true,
    slidesPerView: '3',
    shortSwipes: false,
    longSwipes: false,
    allowTouchMove: false,
    autoplay: {
      delay: 0, 
    }, 
    speed: 5000,
});



mySwiper2 = new Swiper('.h__partners-swiper2', {
    grabCursor: false,
    loop: true,
    slidesPerView: '3',
    shortSwipes: false,
    longSwipes: false,
    allowTouchMove: false,
    autoplay: {
      delay: 0, 
    },  
    speed: 5000,
});
